---
marp: true
title: Contrastive Multivariate Singular Spectrum Analysis
theme: uncover
class: invert
paginate: true
_paginate: false
---

<style scoped>
* {
  font-weight: lighter;
}

.diffeo {
  width: 10px;
}
</style>

<!-- _footer: "$^†$Diffeo Labs, $^‡$Stanford University"  -->

![bg opacity:.5 invert blur](../banner.png)

# Contrastive Multivariate Singular Spectrum Analysis

###### Abdi-Hakin Dirie$^\dagger$, Abubakar Abid$^\ddagger$, James Zou$^\ddagger$

![](./img/diffeo_logo.png) ![h:50px](./img/stanford_logo.png)

---

<!-- _backgroundColor: black -->

![bg right:54% invert](./img/diagram.png)

## Marrying Two Ideas

- <div style="font-size:smaller;">Multivariate Singular Spectrum Analysis (MSSA): A PCA-like method for unsupervised signal decomposition.</div>
- <div style="font-size:smaller;">cPCA [Abid 2018]: An extension to PCA that uses the idea of <em>contrastive learning</em>.</div>

---

# Algorithm

---

$X \in \mathbb{R}^{T \times D}$

A centered, weakly-stationary
$D$-channel time series for $T$ steps.

---

#### Construct the prerequisite "Hankel" matrix:

$$
H_\mathbf{x} =
\begin{pmatrix}
x_1 & x_2 & \ldots & x_W \\
x_2 & x_3 & \ldots & x_{W+1} \\
\vdots & \vdots & \ddots & \vdots \\
x_{T'} & x_{T'+1} & \ldots & x_T \\
\end{pmatrix}
$$
$$H_X = [H_{\mathbf{x}^{(1)}} ; H_{\mathbf{x}^{(2)}} ; \ldots ; H_{\mathbf{x}^{(D)}}]$$

----

#### Compute the covariance matrix:

$$C_X = \frac{1}{T'}H_X^TH_X$$

(Repeat for a background signal $Y$ to get $C_Y$.)

---

#### The "c" in cMSSA

$C = C_X - \alpha C_Y$ for $\alpha \ge 0$

$C$ (hopefully) captures covariance
information specific to $X$ and not $Y$.

---

From here it's the same as standard MSSA:

* Find $E \in \mathbb{R}^{DW \times K}$, the top $K$ eigenvectors of $C$.
* Principal component (PC) space: $A = H_X E$.
* Reconstructed component (RC) space:
  $$R^{(k)}_{tj} = \frac{1}{W_t} \sum^{U_t}_{t' = L_t} A_{t-t'+1, k} \cdot \mathbf{e}^{(k)}_{(j-1)W + t'}$$
  for component $k \in \{1,\ldots,K\}$

---

How do we determine $\alpha$?

---

<!-- _color: black -->
<!-- _backgroundColor: white -->

![bg right](./img/alpha_search_dim_1.png)

---

<!-- _color: black -->
<!-- _backgroundColor: white -->


![bg](./img/alpha_search_pics_1.png)
![bg](./img/alpha_search_dim_2.png)

---

<!-- _color: black -->
<!-- _backgroundColor: white -->


![bg](./img/alpha_search_pics_1.png)
![bg](./img/alpha_search_dim_3.png)

---

<!-- _color: black -->
<!-- _backgroundColor: white -->


![bg](./img/alpha_search_pics_2.png)
![bg](./img/alpha_search_dim_4.png)

---

<!-- _color: black -->
<!-- _backgroundColor: white -->


![bg](./img/alpha_search_pics_3.png)
![bg](./img/alpha_search_dim_4.png)

---

<!-- _color: black -->
<!-- _backgroundColor: white -->


![bg](./img/alpha_search_pics_4.png)
![bg](./img/alpha_search_dim_5.png)

---

<!-- _color: black -->
<!-- _backgroundColor: white -->


![bg](./img/alpha_search_pics_5.png)
![bg](./img/alpha_search_dim_6.png)

---

<!-- _color: black -->
<!-- _backgroundColor: white -->


![bg](./img/alpha_search_pics_6.png)
![bg](./img/alpha_search_dim_7.png)

---

# Synthetic Example

---

<!-- _backgroundColor: black -->

Draw two signals from some common distribution.
![invert](./img/syn_y.png)

---

<style scoped>
img {
  vertical-align: -1.8em;
  text-align: right;
}
</style>

<!-- _backgroundColor: black -->

Add in a small but interesting signal to one:

<span style="color:black;">**+**</span>  ![invert w:900px](./img/syn_x.png)
**+** ![invert w:900px](./img/syn_sub.png)
<hr style="width:1000px">

**=** ![invert w:900px](./img/syn_x.png)

---

<!-- _backgroundColor: black -->

Foreground signal (has special signal):
![invert](./img/syn_x.png)
Background signal:
![invert](./img/syn_y.png)

---

<!-- _backgroundColor: black -->

Standard MSSA run on foreground:
![invert](./img/syn_x_rcs.png)
cMSSA run on foreground (w/ background):
![invert](./img/syn_x_rcs_contrast.png)

---

<!-- _backgroundColor: black -->

Original:
![invert](./img/syn_sub.png)
cMSSA run on foreground (w/ background):
![invert](./img/syn_x_rcs_contrast.png)

---

# Experiments

---

<style scoped>
* {
  text-align: left;
}
</style>

<!-- _backgroundColor: black -->

#### MHEALTH dataset

Researchers collected 2-lead ECG signals while subjects performed a variety of physical activity.

![bg invert vertical right](./img/random_cycling.png)
![bg invert](./img/random_jogging.png)
![bg invert](./img/random_jumping.png)
![bg invert](./img/random_running.png)

---

### Task

- Cluster the time series data by activity:
  - Jumping
  - Cycling
  - Jogging
  - Running
- Evaluate against gold truth clusters
  - Metric: BCubed [Amigó 2009].
  - Outputs precision, recall, and F1.

---

### Models

- **Model-free:** Cluster time signals as they are.
- **MSSA:** For various settings of $W$ and $K$.
- **cMSSA:** MSSA + 4 $\alpha$s discovered by our procedure.

---

<!-- _backgroundColor: black -->

### ECG results

![fit invert](./img/ecg_results.png)

---

Best cMSSA run uses only **~7.8%** of available basis!

(By comparison, best MSSA run uses **37.5%**).

---

<!-- _backgroundColor: black -->

Results on 8-channel electromyogram (EMG) data.
Goal is to cluster 20 activities.

![fit invert](./img/emg_results.png)

MSSA: ~28.1% utilization (18 out of 64)
**cMSSA: ~4.7% utilization (6 out of 128)**

---

### Physical Interpretation

$$
\argmax_{V \in \mathbb{R}^{W \times D}}
P(X*V) - \alpha P(Y*V)
$$
under the constraint $\lVert V \rVert_F = 1$.

$P(\cdot)$ is the power of a univariate signal.

---

<style scoped>
blockquote {
  font-size: larger
}
</style>

> **<span style="color:#6fa8dc;">Shifts the goal</span>** from finding signals that **<span style="color:#e06666;">explain the most</span>** variance to signals that **<span style="color:#93c47d;">matter the most</span>**
> to the analyst.

---

:globe_with_meridians:

cMSSA is available as a Python package at:

https://github.com/aadah/cMSSA

:computer:

---

# Thank you

---

<!-- _backgroundColor: black -->

Other values for $\alpha$ discovered automatically on synthetic data:
- 1.23
- 4.53
- 20.09
- 50.94

![invert bg fit right vertical](./img/syn_1_23.png)
![invert bg fit](./img/syn_4_53.png)
![invert bg fit](./img/syn_20_09.png)
![invert bg fit](./img/syn_50_94.png)
